package bench.test;

import bench.test.userfriendly;

public class runner 
{
    public static void main(String[] args)
    {
    	 userfriendly ruleaza = new userfriendly();
		 ((userfriendly)ruleaza).AWT();	
    }
}